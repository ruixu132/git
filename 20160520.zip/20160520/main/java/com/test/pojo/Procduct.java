package com.test.pojo;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_procduct")
public class Procduct  implements Serializable{
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;            //��ƷId
	private String procductName;  //��Ʒ����
	private int price;        //��Ʒ����
	private String  Origin;       //����
	private String disc;          //����
	private Timestamp createTime; //��������
	
	
	public Procduct() {
		super();
	}
	 
	public Timestamp getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Procduct(String procductName, Integer price, String origin,
			String disc) {
		this.procductName = procductName;
		this.price = price;
		Origin = origin;
		this.disc = disc;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProcductName() {
		return procductName;
	}
	public void setProcductName(String procductName) {
		this.procductName = procductName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getOrigin() {
		return Origin;
	}
	public void setOrigin(String origin) {
		Origin = origin;
	}
	public String getDisc() {
		return disc;
	}
	public void setDisc(String disc) {
		this.disc = disc;
	}
	
	 
	@Override
	public String toString() {
		return "Procduct [id=" + id + ", procductName=" + procductName
				+ ", price=" + price + ", Origin=" + Origin + ", disc=" + disc
				+ ", createTime=" + createTime + "]";
	}

 

  

}
