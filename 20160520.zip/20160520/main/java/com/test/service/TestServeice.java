package com.test.service;

import org.springframework.stereotype.Service;

@Service("testServeice")
public class TestServeice {

	public void getsss(){
		System.out.println("12312312312");
	}
	
}
