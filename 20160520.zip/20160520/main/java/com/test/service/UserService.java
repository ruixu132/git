package com.test.service;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import sun.util.logging.resources.logging;

import com.test.base.ResultMap;
import com.test.cache.RedisCache;
import com.test.cache.RedisEvict;
import com.test.dao.UserDao;
import com.test.pojo.Cart;
import com.test.pojo.User;

@Service("userService")
//@Transactional
public class UserService {

	private static final transient Logger log = Logger
			.getLogger(UserService.class);
	@Resource(name = "userDao")
	private UserDao userDao;

	// Ϊ�䷽������redis����
	@RedisCache(clazz = UserService.class,cacheName="userCache")
	public ResultMap getUser(String id) {
		ResultMap resultMap = new ResultMap();
		User user = userDao.queryUserById(id);
		if (null != user) {
			resultMap.setResultCode(200);
			resultMap.pushData("user", user);
		}
		return resultMap;
	}

	@Transactional(propagation =  Propagation.REQUIRED)
	public ResultMap delete(String id) {
		
		
		ResultMap resultMap = new ResultMap();
//		User user = new User();
//		user.setId(Integer.valueOf(id));
//		try{
		Cart cart  = new Cart();
		cart.setCart_id(1);
		userDao.deleteById(cart);
		int a  =  1/0;
		resultMap.setResultCode(200);
		resultMap.pushData("aa", "success");
//		}catch(Exception e){
//			log.info(e.getMessage());
//		}
		return resultMap;
	}

	public User queryUserByName(String name) {
		return userDao.queryUserByName(name);
	}

	/**
	 * ���ܣ��޸��û���Ϣ
	 * @param user
	 */
	@RedisEvict(clazz=UserService.class,cacheName="userCache")	 
	@Transactional(propagation=Propagation.REQUIRED)
	public ResultMap updateUser(User user) {
		ResultMap resultMap = new ResultMap();
		Integer optValue = userDao.saveObject(user);
		int resultCode = optValue > 0 ? 200 : 300;
		resultMap.setResultCode(resultCode);
		return resultMap;
	}

}
