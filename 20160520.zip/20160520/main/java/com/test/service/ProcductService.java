package com.test.service;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import sun.util.logging.resources.logging;

import com.test.base.ResultMap;
import com.test.dao.ProcductDao;
import com.test.pojo.Procduct;

@Transactional
@Service("procductService")
public class ProcductService {
	private static Logger logger =  Logger.getLogger(ProcductService.class);
	@Resource(name="procductDao")
	
	private ProcductDao procductDao;
	
	/**
	 * ���ܣ���ѯ�����в�Ʒ
	 * @return
	 */
	@Transactional(readOnly=true)
	public ResultMap getPorc(){
		ResultMap resultMap = ResultMap.getInstances();
		try{
		List<Procduct> plist =     procductDao.get();
		resultMap.setResultCode(200);
		resultMap.pushData("procductList", plist);
		}catch(Exception e){
			resultMap.setResultCode(300);
			resultMap.pushData("procductList", e.getMessage());
		}
		logger.info(resultMap);
		return resultMap;
	}
	/**
	 * ���ܣ������Ʒ
	 * @return
	 */
	@Transactional(propagation =Propagation.REQUIRED)
	public ResultMap save(Procduct procduct){
		ResultMap resultMap = ResultMap.getInstances();
		try{procduct.setCreateTime(new Timestamp(System.currentTimeMillis()));
			Integer saveResult =     procductDao.save(procduct);
			if(saveResult>0){
			resultMap.setResultCode(200);
			resultMap.pushData("SaveResult","SAVEOK");
			}
		}catch(Exception e){
			resultMap.setResultCode(300);
			resultMap.pushData("SaveResult", e.getMessage());
			e.printStackTrace();
		}
		return resultMap;
	}
	

}
