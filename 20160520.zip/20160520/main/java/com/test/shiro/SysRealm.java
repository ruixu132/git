package com.test.shiro;

import java.security.Principal;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import com.test.pojo.Role;
import com.test.pojo.User;
import com.test.service.UserService;







 

public class SysRealm extends AuthorizingRealm {
	@Resource(name = "userService")
	private UserService userService;
	@Override
	/**
	 * ���ܣ�Ȩ����Ȩ
	 */
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		 String loginName = (String) principals.fromRealm(getName()).iterator().next();//ȡ��ǰ̨��¼ʱ����ĵ�¼��
		 User user = userService.queryUserByName(loginName);
		 SimpleAuthorizationInfo info  = new SimpleAuthorizationInfo();
		 
		 info.setRoles(user.getRolesName());
		 List<Role> rolelist = user.getRoleList();
		 for (Role object : rolelist) {
			info.addStringPermissions(object.getPermissionsName());
		}
		 return  info;
	}
/**
 *  ���ܣ��û���֤
 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken token) throws AuthenticationException {
		UsernamePasswordToken t = (UsernamePasswordToken) token;
	 
		String userName = t.getUsername();
		String password = new String(t.getPassword());
		User user = null;
		try {
//			int a = 1/0;
			  user = userService.queryUserByName(userName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		 System.out.println(user.toString());
		 String pwdFdb = user.getPassword();
		 
		 SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user,pwdFdb,user.getUsername());
		 
		 
		 return authenticationInfo;
	}

}
