package com.test.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

public class BaseToken {
	private String verfyCode;
 
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BaseToken(){}
	
	 public  UsernamePasswordToken tokens(String userName,String password){
		    	  return  new UsernamePasswordToken (userName,password);
		     
	 }

	public String getVerfyCode() {
		return verfyCode;
	}

	public void setVerfyCode(String verfyCode) {
		this.verfyCode = verfyCode;
	}

	 

	 

}
