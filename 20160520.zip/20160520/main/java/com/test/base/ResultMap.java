package com.test.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ResultMap implements Serializable{

	private Integer resultCode;
	private Map<String,Object> data= new HashMap<String, Object>();
	
	public Integer getResultCode() {
		return resultCode;
	}
	public void setResultCode(Integer resultCode) {
		this.resultCode = resultCode;
	}
	public Map<String, Object> getData() {
		return data;
	}
	public void pushData(String key,Object value) {
	 this.data.put(key,value);
	}
	@Override
	public String toString() {
		return "ResultMap [resultCode=" + resultCode + ", data=" + data + "]";
	}
	
	public  static ResultMap getInstances(){
		return new ResultMap();
	}
	
	
	
}
