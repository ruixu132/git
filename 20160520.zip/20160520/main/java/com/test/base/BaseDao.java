package com.test.base;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.test.pojo.User;

public class BaseDao   {
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	public <T> T queryById(Class clazz,String id){
	   Session session =  getCurrentSession();
		Integer idd= Integer.valueOf(id);
		T t = (T)session.get(clazz, idd);
		if(t!=null){
			session.flush();
		}						
		return  t;
	}
	public Integer deleteById(Object obj){
		  Session session =   getCurrentSession();
		   session.delete(obj);
		   session.flush();
		 
		 return 1;
	}
	
	public Integer saveOrUpdateObject(Object obj){
		Session session =   getCurrentSession();
		session.saveOrUpdate(obj);
		session.flush();
		return 1;
	}
	public Integer saveObject(Object obj){
		Session session =   getCurrentSession();
		session.save(obj);
		session.flush();
		return 1;
	}
	public <T> T getObject(String querysql,String args){
		Session session =   getCurrentSession();
		Query query =   session.createQuery(querysql).setString(0, args);
		return		(T) query.uniqueResult();
	}
	
	public List<?> queryObject(String querysql,Integer firstindex,Integer endindex){
		Session session =   getCurrentSession();
		return session.createQuery(querysql).setFirstResult(firstindex).setMaxResults(endindex).list();
	}
	
	
	public Session getCurrentSession(){
		return sessionFactory.getCurrentSession();
	}

}
