package com.test.controller;

import java.io.UnsupportedEncodingException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.test.pojo.Procduct;
import com.test.service.ProcductService;

@Controller
@RequestMapping("/procduct/")
public class ProcductController {
	
	@Resource(name = "procductService")
	private ProcductService procductService;
	/**
	 * ��ѯ��Ʒ����
	 */
	@RequestMapping("list")
	@ResponseBody
	public Object getProcductList(){
	  return procductService.getPorc();
	}
	
	@RequestMapping("/tolist")
	public String tolist(){
		return "procduct/list";
	}
	@RequestMapping("/toadd")
	public String toadd(){
		return "procduct/add";
	}
	/**
	 * ���ܣ������Ʒ
	 * @param procduct
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/add")
	@ResponseBody
	public Object save(Procduct procduct,HttpServletRequest request) throws UnsupportedEncodingException{
//		String procductName =  request.getParameter("procductName");
//		String price =  request.getParameter("price");
//		String origin =  request.getParameter("origin");
//		String desc =  request.getParameter("disc");
//		Procduct procduct = new Procduct(procductName,Integer.valueOf(price),origin,desc);
//         System.out.println(procduct.toString());
	 
	  return procductService.save(procduct);
	}
	
	

}
