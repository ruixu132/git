package com.test.controller;
import java.util.Enumeration;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;  
import org.apache.shiro.authc.AuthenticationException;  
import org.apache.shiro.authc.UsernamePasswordToken;  
import org.apache.shiro.crypto.hash.SimpleHash;
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.test.pojo.User;
import com.test.service.UserService;
  
 
@Controller()
@RequestMapping("user")
public class HomeController {  
  private static Logger logger =  Logger.getLogger(HomeController.class);
	@Resource(name="userService")
	private UserService userService;
	
    @RequestMapping(value="login",method=RequestMethod.GET)  
    public String loginForm(Model model){  
        model.addAttribute("user", new User());  
        return "login";  
    }  
      /**
       * ���ܣ��û���¼
       * @param request
       * @return
       */
    @RequestMapping(value="logins",method=RequestMethod.POST)  
    public String login(HttpServletRequest request,@RequestParam("userName") String userName,@RequestParam("password") String password){  
    	 
        try {  
        	
        	Enumeration headers =  request.getHeaderNames();
        	 while(headers.hasMoreElements()){
        		 logger.info(headers.nextElement());
        	 }
        	
        	
        	String str = "hello";  
        	String salt = "123";  
        	//�ڲ�ʹ��MessageDigest  
        	String simpleHash = new SimpleHash("SHA-1", str, salt).toString();  
//            if(bindingResult.hasErrors()){  
//                return "login";  
//            }  
        	logger.info("simpleHash = "+simpleHash);
            //ʹ��Ȩ�޹��߽����û���¼����¼�ɹ�������shiro���õ�successUrl�У��������returnûʲô��ϵ��  
            SecurityUtils.getSubject().login(new UsernamePasswordToken(userName, password));  
            return "redirect:/index.jsp";  
        } catch (AuthenticationException e) {  
        	request.setAttribute("errorMessage", "�û��������������!");
            return "redirect:/login.jsp";  
        }  
    }  
      /**
       * �˳�ϵͳ
       * @param redirectAttributes
       * @return
       */
    @RequestMapping(value="logout",method=RequestMethod.GET)    
    public String logout(RedirectAttributes redirectAttributes ){   
        //ʹ��Ȩ�޹������߽����û����˳���������¼��������ʾ��Ϣ  
        SecurityUtils.getSubject().logout();    
        redirectAttributes.addFlashAttribute("message", "���Ѱ�ȫ�˳�");    
        return "redirect:login";  
    }   
      
    @RequestMapping("403")  
    public String unauthorizedRole(){  
        return "403";  
    }

	/**
	 * ����������ѯ�û�
	 * 
	 * @param id
	 * @return
	 */
    @RequestMapping("getUser") 
    @ResponseBody
    public Object getUser(@RequestParam("userId") String id){
    	return userService.getUser(id);
    }
    /**
     * ���ܣ�ɾ���û�
     * @param id
     * @return
     */
    @RequestMapping("delete") 
    @ResponseBody
    public Object deleteUser(@RequestParam("userId") String id){
    	return userService.delete(id);
    }
    /**
     * �����û�
     * @param id
     * @return
     */
    @RequestMapping("update") 
    @ResponseBody
    public Object updateUser(@RequestParam("userId") String id){
    	User user =  new User();
    	user.setId(Integer.valueOf(id));
    	user.setPassword("123456");
    	user.setUsername("loginName");
    	return userService.updateUser(user);
    }
    /**
     * ��ת����¼ҳ��
     * @return
     */
    @RequestMapping("/toWelCome") 
    public Object toWelCome(){
    	logger.info("to welcome!!");
    	return "welcome";
    }
}  