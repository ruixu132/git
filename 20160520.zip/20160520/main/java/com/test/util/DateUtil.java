package com.test.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	/**
	 * ���ܣ�����ת�ַ���
	 * @param l
	 * @return
	 */
	public static String dateToString(Long l){
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(l)); 
	}

}
