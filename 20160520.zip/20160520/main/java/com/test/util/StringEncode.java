package com.test.util;

import java.io.UnsupportedEncodingException;

import org.apache.shiro.crypto.hash.DefaultHashService;
import org.apache.shiro.crypto.hash.HashRequest;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.util.SimpleByteSource;

public class StringEncode {
	private static DefaultHashService hashService = new DefaultHashService();
	
	 private static String  privateSalt ="923379806@qq.com"; //������
	 private static String  encodeType = "SHA-512";          //�����㷨
	 
	 
	 public  static String getEncodewords(String str) throws UnsupportedEncodingException{
		 hashService.setHashAlgorithmName(encodeType);
		 hashService.setPrivateSalt(new SimpleByteSource(privateSalt));
		 HashRequest request = new HashRequest.Builder()  
         .setAlgorithmName("MD5").setSource(ByteSource.Util.bytes(str))  
         .setSalt(ByteSource.Util.bytes(privateSalt)).setIterations(2).build();  
           return hashService.computeHash(request).toHex();  
	 }
	 public static void main(String[] args) throws UnsupportedEncodingException {
		System.out.println(getEncodewords("1111"));
	}
}
