package com.test;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.test.base.BaseDao;
import com.test.base.ResultMap;
import com.test.pojo.Procduct;
import com.test.pojo.User;
import com.test.service.ProcductService;
import com.test.service.TestServeice;

 
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml","classpath:applicationContext-db.xml","classpath:applicationContext-redis.xml"})
public class aa {  
	
	
	@Resource(name="procductService")
	private ProcductService procductService;
	private  static  String driverClassName="com.mysql.jdbc.Driver";
	private	static   String url="jdbc:mysql://localhost:3306/shiro?characterEncoding=utf8";
	
	@Test
	public void ss(){
//		ResultMap  M = procductService.getPorc();
		Procduct procduct = new Procduct("123",12,"sichuan","123");
		User u = new User();
		u.setId(12);
		u.setPassword("21345");
		u.setUsername("1111111");
		
		//new BaseDao().saveObject(u);
//		procductService.save(procduct);
    	 
	}
	
	public static void main(String[] args) throws Exception {
		Class.forName(driverClassName);
		Connection c =    DriverManager.getConnection(url,"root","root");
		c.createStatement().execute("insert into t_procduct(origin,disc,price,procductName)"
				+ "values ('����','����',12,'ɽҩ')");
		
		
	}
}
