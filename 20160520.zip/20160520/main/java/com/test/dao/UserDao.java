package com.test.dao;

import org.springframework.stereotype.Repository;

import com.test.base.BaseDao;
import com.test.pojo.User;

@Repository("userDao")
public class UserDao  extends BaseDao{

	public User queryUserById(String id){
		User user =  queryById(User.class, id);
		if(null !=user){
			return user;
		}
		return user;
	}
	
	public int deleteUserById(User user){
		return deleteById(user);
	}
	
	public User queryUserByName(String name){
		return (User) getObject("from User where username=?",name);
	}
	
	public int updateUser(User user){
//		User u = (User)queryById(User.class, user.getId().toString());
		return saveObject(user);
	}
	
}
