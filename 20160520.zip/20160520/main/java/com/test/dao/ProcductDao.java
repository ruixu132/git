package com.test.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.test.base.BaseDao;
import com.test.pojo.Procduct;

@Repository("procductDao")
public class ProcductDao extends  BaseDao{
	
	
	public List<Procduct> get(){
		List<Procduct> plist =  new ArrayList<Procduct>();
		
		plist = (List<Procduct>) this.queryObject("from Procduct", 0, 100);
		return plist;
	} 
	
	public Integer save(Procduct procduct){
		return this.saveObject(procduct);
	} 
	

}
